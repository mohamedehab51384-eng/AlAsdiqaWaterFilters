package com.alasdiqa.waterfilters;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {

    private final int BLUE = Color.rgb(8,105,201);
    private final int LIGHT = Color.rgb(244,250,255);
    private final int GREEN = Color.rgb(34,180,92);
    private final int RED = Color.rgb(220,45,45);
    private LinearLayout content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private TextView tv(String text, float size, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(null, android.graphics.Typeface.BOLD);
        v.setPadding(12, 10, 12, 10);
        return v;
    }

    private Button btn(String text, int bg, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setBackgroundColor(bg);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                0, dp(62), 1f);
        p.setMargins(dp(6), dp(6), dp(6), dp(6));
        b.setLayoutParams(p);
        return b;
    }

    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout base(String title) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(LIGHT);
        outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView header = tv(title, 21, Color.WHITE);
        header.setBackgroundColor(BLUE);
        header.setPadding(dp(16), dp(16), dp(16), dp(16));
        outer.addView(header, new LinearLayout.LayoutParams(-1, dp(62)));

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(14), dp(14), dp(24));
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(content);
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(Color.WHITE);
        nav.addView(navBtn("الرئيسية", v -> showHome()));
        nav.addView(navBtn("الفلاتر", v -> showFilters()));
        nav.addView(navBtn("العروض", v -> showOffers()));
        nav.addView(navBtn("موقعنا", v -> showLocation()));
        nav.addView(navBtn("المزيد", v -> showContact()));
        outer.addView(nav, new LinearLayout.LayoutParams(-1, dp(62)));

        setContentView(outer);
        return outer;
    }

    private TextView navBtn(String text, View.OnClickListener l) {
        TextView v = tv(text, 12, BLUE);
        v.setOnClickListener(l);
        v.setPadding(4, 8, 4, 8);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, -1, 1f));
        return v;
    }

    private TextView paragraph(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(16);
        v.setTextColor(Color.DKGRAY);
        v.setGravity(Gravity.RIGHT);
        v.setPadding(dp(6), dp(10), dp(6), dp(10));
        return v;
    }

    private TextView card(String title, String body) {
        TextView v = new TextView(this);
        v.setText(title + "\n" + body);
        v.setTextSize(16);
        v.setTextColor(Color.rgb(25,55,85));
        v.setGravity(Gravity.RIGHT);
        v.setPadding(dp(16), dp(16), dp(16), dp(16));
        v.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(6), 0, dp(6));
        v.setLayoutParams(p);
        return v;
    }

    private void showHome() {
        base("الأصدقاء لفلاتر المياه");
        ImageView logo = new ImageView(this);
        logo.setImageResource(com.alasdiqa.waterfilters.R.drawable.alasdiqa_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setAdjustViewBounds(true);
        logo.setPadding(dp(8), dp(8), dp(8), dp(8));
        content.addView(logo, new LinearLayout.LayoutParams(-1, dp(210)));

        TextView slogan = tv("مياه نقية… صحة لكل أسرتك", 18, Color.rgb(20,75,120));
        content.addView(slogan);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(btn("🔧 احجز صيانة", BLUE, v -> showBooking()));
        row1.addView(btn("💧 اطلب فلتر", BLUE, v -> showFilters()));
        content.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(btn("🔄 تغيير الشمعات", GREEN, v -> showCartridges()));
        row2.addView(btn("📞 اتصل بنا", Color.rgb(100,70,190), v -> showContact()));
        content.addView(row2);

        TextView offer = tv("🎁 العروض والخصومات لفترة محدودة", 18, Color.WHITE);
        offer.setBackgroundColor(RED);
        offer.setPadding(dp(12), dp(18), dp(12), dp(18));
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, -2);
        op.setMargins(0, dp(12), 0, dp(12));
        content.addView(offer, op);

        content.addView(card("⭐ خدمات الأصدقاء", 
                "بيع وتركيب جميع أنواع فلاتر المياه\n" +
                "🔧 صيانة دورية وتنظيف الفلتر\n" +
                "🔄 تغيير الشمعات الأصلية\n" +
                "💧 فحص وتحسين جودة المياه\n" +
                "🛡️ ضمان على الخدمة"));
    }

    private void showFilters() {
        base("منتجات وخدمات الأصدقاء");

        content.addView(card("💧 NEW AQUA SUN — 7 STAGES",
                "فلتر 7 مراحل للتنقية متعددة المراحل.\nالسعر: اتصل بنا لمعرفة السعر الحالي."));
        addProductButton("اطلب فلتر 7 مراحل", "فلتر NEW AQUA SUN 7 STAGES");

        ImageView seven = new ImageView(this);
        seven.setImageResource(com.alasdiqa.waterfilters.R.drawable.aqua_sun_7_stages);
        seven.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        seven.setAdjustViewBounds(true);
        content.addView(seven, new LinearLayout.LayoutParams(-1, dp(270)));

        content.addView(card("🔄 تغيير الشمعات",
                "تغيير الشمعات الأصلية وفحص حالة الفلتر.\nالسعر: اتصل بنا لمعرفة السعر الحالي."));
        addProductButton("احجز تغيير الشمعات", "تغيير الشمعات");

        ImageView cartridges = new ImageView(this);
        cartridges.setImageResource(com.alasdiqa.waterfilters.R.drawable.filter_cartridges);
        cartridges.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        cartridges.setAdjustViewBounds(true);
        content.addView(cartridges, new LinearLayout.LayoutParams(-1, dp(270)));

        content.addView(card("🔧 صيانة دورية",
                "فحص وتنظيف الفلتر والتأكد من التوصيلات وحالة المراحل.\nالسعر: اتصل بنا لمعرفة السعر الحالي."));
        addProductButton("احجز صيانة", "صيانة دورية");

        content.addView(card("💧 فلاتر 5 مراحل",
                "حل منزلي متعدد المراحل. أرسل طلبك لمعرفة الموديلات المتاحة والسعر الحالي."));
        addProductButton("اطلب فلتر 5 مراحل", "فلتر 5 مراحل");

        content.addView(card("💧 فلاتر 3 مراحل",
                "تنقية أساسية للمياه من الرواسب والشوائب. أرسل طلبك لمعرفة الموديلات المتاحة."));
        addProductButton("اطلب فلتر 3 مراحل", "فلتر 3 مراحل");
    }

    private void addProductButton(String title, String serviceName) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setOnClickListener(v -> showBookingWithService(serviceName));
        content.addView(b);
    }

    private void showBookingWithService(String serviceName) {
        showBooking();
        // The booking screen remains editable so the customer can add details.
        TextView selected = paragraph("الخدمة المختارة: " + serviceName);
        content.addView(selected, 0);
    }

    private void showBooking() {
        base("حجز خدمة");
        content.addView(paragraph("املأ البيانات التالية وسنتواصل معك لتأكيد الطلب:"));

        EditText name = field("الاسم الكامل");
        EditText phone = field("رقم الهاتف");
        EditText address = field("العنوان");
        EditText notes = field("ملاحظات (اختياري)");
        content.addView(name); content.addView(phone); content.addView(address); content.addView(notes);

        Spinner service = new Spinner(this);
        String[] services = {"صيانة دورية", "تغيير الشمعات", "تركيب فلتر جديد", "تغيير مرحلة معينة"};
        service.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, services));
        content.addView(service);

        Button send = new Button(this);
        send.setText("إرسال الطلب عبر واتساب");
        send.setAllCaps(false);
        send.setTextColor(Color.WHITE);
        send.setBackgroundColor(GREEN);
        send.setOnClickListener(v -> {
            String msg = "طلب خدمة - الأصدقاء لفلاتر المياه%0Aالاسم: " +
                    Uri.encode(name.getText().toString()) +
                    "%0Aالهاتف: " + Uri.encode(phone.getText().toString()) +
                    "%0Aالعنوان: " + Uri.encode(address.getText().toString()) +
                    "%0Aالخدمة: " + Uri.encode(service.getSelectedItem().toString()) +
                    "%0Aملاحظات: " + Uri.encode(notes.getText().toString());
            openUrl("https://wa.me/201014763597?text=" + msg);
        });
        content.addView(send);
    }

    private void addQuickWhatsApp(String message) {
        Button b = new Button(this);
        b.setText("💬 إرسال استفسار على واتساب");
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(GREEN);
        b.setOnClickListener(v -> openUrl("https://wa.me/201014763597?text=" + Uri.encode(message)));
        content.addView(b);
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(16);
        e.setGravity(Gravity.RIGHT);
        e.setSingleLine(false);
        e.setPadding(dp(14), dp(10), dp(14), dp(10));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(58));
        p.setMargins(0, dp(5), 0, dp(5));
        e.setLayoutParams(p);
        return e;
    }

    private void showCartridges() {
        base("تغيير الشمعات");
        content.addView(card("الخدمة", "اختار نوع الخدمة المطلوبة ثم اضغط للحجز."));
        Button b = new Button(this);
        b.setText("احجز تغيير الشمعات");
        b.setAllCaps(false);
        b.setOnClickListener(v -> showBooking());
        content.addView(b);
    }

    private void showOffers() {
        base("العروض والخصومات");
        content.addView(card("🎁 عرض خاص", "خصومات وعروض لفترة محدودة — تابع التطبيق لمعرفة أحدث العروض."));
        content.addView(card("💧 فلتر 7 مراحل", "اسألنا عن السعر والعرض المتاح حاليًا."));
        content.addView(card("🔧 صيانة شاملة", "احجز موعد الصيانة وسنتواصل معك للتأكيد."));
    }

    private void showLocation() {
        base("موقعنا");
        content.addView(card("📍 الأصدقاء لفلاتر المياه", "الزقازيق – الشرقية، مصر"));
        Button map = new Button(this);
        map.setText("فتح الموقع على خرائط Google");
        map.setAllCaps(false);
        map.setOnClickListener(v -> openUrl("https://www.google.com/maps/search/?api=1&query=" + Uri.encode("الأصدقاء لفلاتر المياه الزقازيق الشرقية مصر")));
        content.addView(map);
        content.addView(card("أرقام التواصل", "01286389402\n01014763597"));
    }

    private void showContact() {
        base("تواصل معنا");
        content.addView(paragraph("تواصل معنا للحجز أو الاستفسار:"));
        Button call1 = new Button(this);
        call1.setText("📞 اتصال 01286389402");
        call1.setAllCaps(false);
        call1.setOnClickListener(v -> call("01286389402"));
        content.addView(call1);

        Button call2 = new Button(this);
        call2.setText("📞 اتصال 01014763597");
        call2.setAllCaps(false);
        call2.setOnClickListener(v -> call("01014763597"));
        content.addView(call2);

        Button wa = new Button(this);
        wa.setText("💬 واتساب");
        wa.setAllCaps(false);
        wa.setTextColor(Color.WHITE);
        wa.setBackgroundColor(GREEN);
        wa.setOnClickListener(v -> openUrl("https://wa.me/201014763597"));
        content.addView(wa);

        Button fb = new Button(this);
        fb.setText("Facebook");
        fb.setAllCaps(false);
        fb.setOnClickListener(v -> openUrl("https://www.facebook.com/share/1Cugtcz11z/"));
        content.addView(fb);

        Button ig = new Button(this);
        ig.setText("Instagram");
        ig.setAllCaps(false);
        ig.setOnClickListener(v -> openUrl("https://www.instagram.com/momoehab51384?stkn=MWl0Nm01dDVzMTZ3aQ%3D%3D&utm_source=qr"));
        content.addView(ig);

        Button tk = new Button(this);
        tk.setText("TikTok");
        tk.setAllCaps(false);
        tk.setOnClickListener(v -> openUrl("https://www.tiktok.com/@mohamed.ehab8684"));
        content.addView(tk);
    }

    private void call(String number) {
        Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
        startActivity(i);
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception ignored) {}
    }
}
